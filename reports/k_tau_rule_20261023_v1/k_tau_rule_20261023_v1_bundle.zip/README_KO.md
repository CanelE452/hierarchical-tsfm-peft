# K_tau 규칙 실험 결과 묶음

[확인] 캠페인: k_tau_rule_20261023_v1
[확인] 최종 판정: ADOPT. 각 데이터 seed92601–92610의 V MSE 중앙값 기준.
[확인] 사전등록 커밋: 480c2211af3fd195916645b13ba952084a7b4eb9

먼저 reports/k_tau_rule_20261023_v1/RESULTS_KO.md를 읽으세요.
전체 수치는 같은 폴더 SUMMARY.csv, seed별 기록은 RUNS.csv에 있습니다.
FIG_K_CURVE.png/svg와 FIG_BOXPLOT.png/svg에 비교 그림이 있습니다.

```text
dataset             K    median MSE       Raw MSE     change
jena                6   0.697770415   0.849194139   -17.83%
ETTh1               4   0.279642620   0.283404537   -1.33%
ETTh2_safe17400     4   0.277230742   0.259554874   +6.81%
appliances         10   0.282018641   0.347579137   -18.86%
```

Jena는 기존 K 후보 최선 대비 두 seed 손해가 10seed IQR보다 커 LIMITATION입니다.
ETTh2_safe17400은 사전등록대로 판정에서 제외한 기술 결과입니다.
이 결과는 반복 사용한 검증셋 V의 결과입니다.

포함: 이번 실험의 등록 소스11개, 보고서·공개 scalar 영수증 전체,
원래 그림·중단 기록을 보존한 attempts, 검증 스크립트4개와 관련 README,
38회 실행의 console log와 controller 영수증.
대용량 모델·checkpoint·prediction 배열·원자료·전체 학습 캐시는 포함하지 않습니다.

재현 안내는 reports/k_tau_rule_20261023_v1/REPRODUCE.md에 있습니다.
공개 표로 수치·그림을 재생성하는 절차가 들어 있습니다.
보존/계약 검증기의 일부와 학습 실행은 기존 전체 저장소·자산을 필요로 합니다.
이 ZIP은 결과와 증거 묶음이며 독립된 전체 학습 환경 설치본은 아닙니다.

MANIFEST_SHA256.txt는 자기 자신을 제외한 모든 압축 항목의 SHA256을 기록합니다.
